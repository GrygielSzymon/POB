﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizza
{
    internal enum PizzaSize
    {
        Small = 30,
        Medium = 40,
        Large = 50
    }
}
